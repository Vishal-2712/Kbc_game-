const questions = [
    {
        question: "What is the capital of France?",
        options: ["Berlin", "Madrid", "Paris", "Rome"],
        answer: "Paris"
    },
    {
        question: "Who wrote 'Romeo and Juliet'?",
        options: ["Charles Dickens", "Mark Twain", "William Shakespeare", "Jane Austen"],
        answer: "William Shakespeare"
    },
    {
        question: "What is the largest planet in our solar system?",
        options: ["Earth", "Jupiter", "Saturn", "Mars"],
        answer: "Jupiter"
    },
    {
        question: "Which element has the chemical symbol 'O'?",
        options: ["Gold", "Oxygen", "Silver", "Hydrogen"],
        answer: "Oxygen"
    },
    {
        question: "What is the boiling point of water at sea level in degrees Celsius?",
        options: ["50°C", "75°C", "100°C", "120°C"],
        answer: "100°C"
    }
];

let currentQuestionIndex = 0;
let playerName = "";

function startGame() {
    playerName = prompt("Enter your name:");
    document.getElementById('qr-code').classList.add('hidden');
    showQuestion();
}

function showQuestion() {
    const questionData = questions[currentQuestionIndex];
    document.getElementById('question').innerText = questionData.question;

    const optionsContainer = document.getElementById('options');
    optionsContainer.innerHTML = '';
    questionData.options.forEach(option => {
        const button = document.createElement('button');
        button.innerText = option;
        button.onclick = () => checkAnswer(option);
        optionsContainer.appendChild(button);
    });

    document.getElementById('congratulations').classList.add('hidden');
    document.getElementById('feedback').classList.add('hidden');
    document.getElementById('next-question').classList.add('hidden');
}

function checkAnswer(selectedOption) {
    const correctAnswer = questions[currentQuestionIndex].answer;
    if (selectedOption === correctAnswer) {
        document.getElementById('winner-name').innerText = playerName;
        document.getElementById('congratulations').classList.remove('hidden');
        document.getElementById('next-question').classList.remove('hidden');
    } else {
        document.getElementById('feedback').innerText = "Incorrect answer! Try again.";
        document.getElementById('feedback').classList.remove('hidden');
    }
}

document.getElementById('next-question').onclick = () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        alert("Game Over! Thanks for playing!");
    }
};

// Start the game
startGame();
